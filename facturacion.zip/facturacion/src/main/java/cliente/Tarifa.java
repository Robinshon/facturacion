package cliente;

public class Tarifa {
    private double precioPorSegundo;
    public Tarifa(double precioPorSegundo){
        this.precioPorSegundo = precioPorSegundo;
    }
    public double getPrecioPorSegundo() {
        return  precioPorSegundo;
    }
}
